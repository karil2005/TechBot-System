import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, sendPasswordResetEmail, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js"; // Import Firestore

const firebaseConfig = {
    apiKey: "AIzaSyAfyXlKY-x2Fgrz20wYYXw7AAaK1kc3SVQ",
    authDomain: "techbot-56772.firebaseapp.com",
    projectId: "techbot-56772",
    storageBucket: "techbot-56772.appspot.com",
    messagingSenderId: "1008993231244",
    appId: "1:1008993231244:web:992aae95be7e56130776a9"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);

// Initialize Firestore
const db = getFirestore(app); // Correctly initialize Firestore

window.db = db; // Now you can reference 'db' globally

window.togglePassword = function (inputId, eyeIcon) {
    const input = document.getElementById(inputId);
    if (input.type === "password") {
        input.type = "text";
        eyeIcon.src = "./images/eyeview.png";  // Visible password icon
    } else {
        input.type = "password";
        eyeIcon.src = "./images/eyehidden.png";  // Hidden password icon
    }
};

function showMessage(message, loginButton) {
    const loginButtonMessage = document.getElementById(loginButton);
    loginButtonMessage.textContent = message;
}

document.addEventListener("DOMContentLoaded", function() {
    document.body.style.visibility = "visible";

    function validateStudentNumber() {
        let StudentNumberInput = document.getElementById("StudentNumber");
        let StudentNumberMessage = document.getElementById("StudentNumberError");
        let StudentNumberPattern = /^\d{6}$/;

        if (StudentNumberInput.value.trim() === "") {
            StudentNumberMessage.textContent = "";
        } else if (!StudentNumberPattern.test(StudentNumberInput.value)) {
            StudentNumberMessage.textContent = "Student Number must be exactly 6 digits!";
        } else {
            StudentNumberMessage.textContent = ""; 
        }
    }

    document.getElementById("StudentNumber").addEventListener("input", validateStudentNumber);
    document.getElementById("StudentNumber").addEventListener("blur", validateStudentNumber); 

    function validateEmail() {
        let emailInput = document.getElementById("email");
        let emailMessage = document.getElementById("emailError");
        let emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

        if (emailInput.value.trim() === "") {
            emailMessage.textContent = "";
        } else if (!emailPattern.test(emailInput.value)) {
            emailMessage.textContent = "Please enter a valid email address!";
        } else {
            emailMessage.textContent = ""; 
        }
    }

    document.getElementById("email").addEventListener("input", validateEmail);
    document.getElementById("email").addEventListener("blur", validateEmail);

    const forgotPasswordLink =document.getElementById("forgotPasswordLink");
    forgotPasswordLink.addEventListener("click", function(event){
        event.preventDefault()

        const email = document.getElementById("email").value;

        sendPasswordResetEmail(auth, email)
        .then(() => {
            //Password reset email sent!
            //...

            alert("email sent")
        })
        .catch((error) => {
            const errorCode = error.code;
            const errorMessage = error.message;
            alert(errorMessage)

        })
    })

    const loginButton = document.getElementById('loginButton');
    loginButton.addEventListener('click', async (event) => {
        event.preventDefault();
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        const studentNumber = document.getElementById('StudentNumber').value; // Getting the student number from the login form
        
    
        try {
            const userCredential = await signInWithEmailAndPassword(auth, email, password);
            const user = userCredential.user;
    
            // Fetch the user's document from Firestore
            const userDoc = await getDoc(doc(db, "users", user.uid));
            
            if (userDoc.exists()) {
                const userData = userDoc.data();
                
                // Compare the student number entered with the one stored in Firestore
            if (userData.studentNumber === studentNumber) {
                // If the student numbers match, proceed to the homepage
                localStorage.setItem('loggedInUserId', user.uid);
                window.location.href = 'homepageicon.html';
            } else {
                alert('Student number does not match our records');
            }
        } else {
            alert('No user found in our records');
        }
    } catch (error) {
        console.error('Error during login:', error);
        alert('Login failed. Please check your credentials.');
    }
});
});