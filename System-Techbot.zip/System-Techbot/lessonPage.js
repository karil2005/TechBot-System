import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getFirestore, getDoc, doc,setDoc, updateDoc, collection, getDocs, Timestamp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAfyXlKY-x2Fgrz20wYYXw7AAaK1kc3SVQ",
    authDomain: "techbot-56772.firebaseapp.com",
    projectId: "techbot-56772",
    storageBucket: "techbot-56772.appspot.com",
    messagingSenderId: "1008993231244",
    appId: "1:1008993231244:web:992aae95be7e56130776a9"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
window.db = db;
window.firestoreFns = { getDoc, doc };

document.addEventListener("DOMContentLoaded", function () {
    let optionSelected = false;

    const openQuizBtn = document.getElementById('openQuizModal');
    const quizModal = document.getElementById('quizModal');
    const confirmStartQuizBtn = document.getElementById('confirmStartQuiz');
    const cancelQuizBtn = document.getElementById('cancelQuiz');
    const lessonModal = document.getElementById("lessonModal");
    const closeLesson = document.getElementById("closeLesson");
    const takeQuizModal = document.getElementById('takeQuizModal');
    const quizTitle = document.getElementById('quizTitle');
    const quizBody = document.getElementById('quizBody');
    
    const questionNumber = document.getElementById('questionNumber');
    const questionText = document.getElementById('questionText');
    const feedback = document.getElementById('feedback');
    const optionsContainer = document.getElementById('optionsContainer');
    const currentScore = document.getElementById('currentScore');
    const nextQuestionBtn = document.getElementById('nextQuestion');
    const progressFill = document.querySelector('.progress-fill');

    let currentQuestionIndex = 0;
    let userScore = 0;
    let quizData = [];
    let lessonData = {};
    let lessonTitle = "";
    

    const urlParams = new URLSearchParams(window.location.search);
    const lessonId = urlParams.get('lessonId');

    if (lessonId) {
        const lessonRef = doc(db, "lessons", lessonId);
        getDoc(lessonRef).then((docSnap) => {
            if (docSnap.exists()) {
                const lessonData = docSnap.data();
                lessonTitle = lessonData.title;

                lessonModal.querySelector('.lesson-header').innerHTML = `<h1>${lessonTitle}</h1>`;
                const lessonContent = lessonData.fullLesson 
                    ? lessonData.fullLesson.replace(/\n/g, '<br>') 
                    : '<i>No lesson content available.</i>';
                lessonModal.querySelector('.lesson-content').innerHTML = lessonContent;
                lessonModal.style.display = 'flex';
            } else {
                console.log("No lesson found with the provided ID");
            }
        }).catch((error) => {
            console.error("Error fetching lesson:", error);
        });
    }

    const userId = localStorage.getItem('loggedInUserId');
if (userId && lessonId) {
    const resultRef = doc(db, "users", userId, "quizResults", lessonId);
    getDoc(resultRef).then(docSnap => {
        if (docSnap.exists()) {
            const resultData = docSnap.data();
            if (resultData.score === 10) {
                openQuizBtn.disabled = true;
                openQuizBtn.textContent = "Quiz Completed!";
                openQuizBtn.style.backgroundColor = "#ccc";
                openQuizBtn.style.cursor = "not-allowed";
            }
        }
    });
}


    openQuizBtn.addEventListener('click', function() {
        quizModal.style.display = 'flex';
    });

    cancelQuizBtn.addEventListener('click', function() {
        quizModal.style.display = 'none';
    });

    closeLesson.addEventListener('click', function() {
        window.location.href = "homepageicon.html";
    });

    confirmStartQuizBtn.addEventListener('click', function() {
        console.log('Start Quiz Button clicked');
        lessonModal.style.display = 'none';
        quizModal.style.display = 'none';
        takeQuizModal.style.display = 'flex';
        startQuiz();
    });

    async function startQuiz() {
        console.log("Start Quiz function executed");
        const lessonRef = doc(db, "lessons", lessonId);
        const lessonSnap = await getDoc(lessonRef);

        if (lessonSnap.exists()) {
            lessonData = lessonSnap.data();
            quizData = lessonData.quiz || [];

            if (quizData.length > 0) {
                quizTitle.textContent = lessonData.title; // Set lesson title in the quiz modal
                currentQuestionIndex = 0;
                userScore = 0;
                currentScore.textContent = `0/${quizData.length}`;
                feedback.textContent = "";
                displayQuizQuestion();
            } else {
                quizBody.innerHTML = `<p>No quiz available for this lesson.</p>`;
            }
        } else {
            console.error("No such lesson!");
            alert("Failed to start quiz. Lesson not found.");
        }
    }

    function displayQuizQuestion() {
        optionSelected = false;

        const currentQuestion = quizData[currentQuestionIndex];
    
        questionNumber.textContent = `${currentQuestionIndex + 1}/${quizData.length}`;
        questionText.innerHTML = `
            <strong style="color: black;">${currentQuestion.questionDesc ? currentQuestion.questionDesc : ''} </strong><br>
        `;
    
        feedback.textContent = "";
        optionsContainer.innerHTML = "";
    
        currentQuestion.options.forEach(option => {
            const btn = document.createElement('button');
            btn.type = "button";
            btn.textContent = option;
            btn.onclick = () => selectOption(btn, currentQuestion.options[currentQuestion.correctAnswer]);
            optionsContainer.appendChild(btn);
        });
    
        const progressPercent = (currentQuestionIndex / quizData.length) * 100;
        progressFill.style.width = `${progressPercent}%`;
    
    }
    

    function selectOption(selectedBtn, correctAnswer) {
        if (optionSelected) return;  // Prevent multiple selections
        optionSelected = true;        // Mark that an option has been selected
        
        if (!correctAnswer) {
            feedback.textContent = "Error: No correct answer provided!";
            feedback.style.color = "red";
            return;
        }

        const allButtons = optionsContainer.querySelectorAll('button');
        allButtons.forEach(btn => btn.disabled = true); // Disable all buttons after choosing one
    
        if (selectedBtn.textContent.trim().toLowerCase() === correctAnswer.trim().toLowerCase()) {
            feedback.textContent = "Correct!";
            feedback.style.color = "green";
            userScore++;
            currentScore.textContent = `${userScore}/${quizData.length}`;
            selectedBtn.style.backgroundColor = 'lightgreen'; // correct answer highlight
            progressFill.style.backgroundColor = 'blue'; // Correct: blue progress
        } else {
            feedback.textContent = "Wrong!";
            feedback.style.color = "darkred";
            selectedBtn.style.backgroundColor = '#f08080'; // wrong answer highlight
    
            allButtons.forEach(btn => {
                if (btn.textContent.trim().toLowerCase() === correctAnswer.trim().toLowerCase()) {
                    btn.style.backgroundColor = 'lightgreen'; // Highlight the correct answer
                }
            });
    
            progressFill.style.backgroundColor = 'red'; // Wrong: red progress
        }
    }
    

    nextQuestionBtn.addEventListener('click', function () {
        if (currentQuestionIndex < quizData.length - 1) {
            currentQuestionIndex++;
            optionSelected = false; // <--- Reset option lock for next question
            displayQuizQuestion();
        } else {
            showAchievementModal(userScore, quizData.length, lessonTitle && lessonData.badge ? lessonData.badge : 'Default Badge');
        }
        
    });
    
    
    window.closequiz = function () {
        takeQuizModal.style.display = 'none';   // Hide the quiz modal
        lessonModal.style.display = 'flex';     // Show the lesson modal again
        currentQuestionIndex = 0;               // Reset the quiz state
        userScore = 0;
        feedback.textContent = "";
        if (quizData.length > 0) {
            currentScore.textContent = `0/${quizData.length}`;
        } else {
            currentScore.textContent = `0/0`;
        }
        progressFill.style.width = `0%`;
        optionsContainer.innerHTML = "";  // Also clear old options
        questionText.innerHTML = "";       // Clear question text
    };
   
    
    async function showAchievementModal(score, total, badgeName) {
        const achievementModal = document.createElement('div');
        achievementModal.className = 'modal';
        achievementModal.style.display = 'flex';
        achievementModal.id = 'achievementModal';
        takeQuizModal.classList.add('blurred-background');
    
        let message = '';
        let badgePath = '';  // Default empty path
    
        // Logic to set message based on score
        if (score === total) {
            message = 'Great! You got Achievement!';
        } else if (score >= total - 2) {
            message = "Great job! Don't give up!";
        } else if (score === 5) {
            message = "You're halfway there!";
        } else {
            message = "You did great, better luck next time!";
        }
    
        // Check if the score is perfect
        if (score === total) {
            // Fetch the badge from Firestore
            const lessonRef = doc(db, "lessons", lessonId);
            const lessonSnap = await getDoc(lessonRef);
            if (lessonSnap.exists()) {
                const lessonData = lessonSnap.data();
                badgeName = lessonData.badge || 'Default Badge';  // Use the badge name from Firestore or default
                badgePath = `badges/${badgeName.toLowerCase().replace(/\s+/g, '-')}.png`;  // Path to badge image
            }
        }
    
        const modalContent = document.createElement('div');
        modalContent.className = 'modal-content achievement-box';
    
        modalContent.innerHTML = `
    <h2>${message}</h2>
    ${
        score === total
        ? `<img src="badges/${badgeName}" alt="Badge Image" style="max-height: 120px;">
           <p>${badgeName.replace('.png', '')}</p>`
        : `<img src="images/sadbot.png" alt="Sad Bot" style="width: 150px; display: block; margin: 10px auto;">
           <br>
           <button id="retryQuizBtn" class="start-btn" style="margin-bottom: 15px;">Retry Quiz</button>`
    }
`;

    

        // Save quiz result to user document
const userId = localStorage.getItem('loggedInUserId');
if (userId) {
    const resultRef = doc(db, "users", userId, "quizResults", lessonId);  // subcollection per lesson

    const resultData = {
        score: score,
        total: total,
        timestamp: Timestamp.now(),
    };

    if (score === total) {
        resultData.badge = badgeName.replace('.png', ''); // Save badge name (without .png)
    }

    try {
        await setDoc(resultRef, resultData);  // Will create or overwrite result for the lesson
        console.log("Quiz result saved successfully.");
    } catch (error) {
        console.error("Error saving quiz result:", error);
    }
} else {
    console.warn("User not logged in. Cannot save quiz result.");
}
    
        const closeButton = document.createElement('button');
        closeButton.className = 'start-btn';
        closeButton.textContent = 'Close';
        modalContent.appendChild(closeButton);
    
        achievementModal.appendChild(modalContent);
        document.body.appendChild(achievementModal);
    
        // ✅ Add event listener for close button
        closeButton.addEventListener('click', function() {
            closeAchievementModal();
        });
    
        if (score !== total) {
            const retryBtn = modalContent.querySelector('#retryQuizBtn');
            retryBtn.addEventListener('click', function () {
                closeAchievementModal();
        
                // Reset quiz state BEFORE starting
                currentQuestionIndex = 0;
                userScore = 0;
                currentScore.textContent = `0/${quizData.length}`;
                feedback.textContent = "";
                progressFill.style.width = `0%`;
                optionsContainer.innerHTML = "";
                questionText.innerHTML = "";
        
                takeQuizModal.style.display = 'flex';
                startQuiz();  // Restart the quiz
            });
        }
    }        
        
    
    // ✅ Define closeAchievementModal globally
    function closeAchievementModal() {
        const achievementModal = document.getElementById('achievementModal');
        if (achievementModal) {
            takeQuizModal.classList.remove('blurred-background');
            achievementModal.remove();
            
        }
        // After closing, show lessonModal again
        const lessonModal = document.getElementById('lessonModal');
        if (lessonModal) {
            lessonModal.style.display = 'flex';
            takeQuizModal.style.display = 'none'; // explicitly hide it

        }
    }
    
    
});
