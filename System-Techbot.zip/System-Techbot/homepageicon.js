import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth, signOut } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, getDoc, doc, collection, getDocs } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js"; // Import Firestore

const firebaseConfig = {
    apiKey: "AIzaSyAfyXlKY-x2Fgrz20wYYXw7AAaK1kc3SVQ",
    authDomain: "techbot-56772.firebaseapp.com",
    projectId: "techbot-56772",
    storageBucket: "techbot-56772.appspot.com",
    messagingSenderId: "1008993231244",
    appId: "1:1008993231244:web:992aae95be7e56130776a9"
};

const app = initializeApp(firebaseConfig);


const auth = getAuth(app);

// Initialize Firestore
const db = getFirestore(app); // Correctly initialize Firestore
window.db = db;
window.firestoreFns = { getDoc, doc };

document.addEventListener('DOMContentLoaded', function() {
  const userNameElement = document.querySelector('.user-name');
  const profileIcon = document.querySelector(".user-icon");
  const dropdownMenu = document.getElementById("dropdownMenu");
  const userId = localStorage.getItem('loggedInUserId');

  profileIcon.addEventListener('click', function () {
    console.log("Dropdown icon clicked");
    dropdownMenu.style.display = dropdownMenu.style.display === "block" ? "none" : "block";
  });
     
  // Close dropdown if clicked outside
  document.addEventListener('click', function(event) {
    if (!profileIcon.contains(event.target) && !dropdownMenu.contains(event.target)) {
        dropdownMenu.style.display = "none";
    }
});


// Achievement button functionality
const achievementBtn = document.getElementById("achievementbtn");
achievementBtn.addEventListener("click", function () {
    window.location.href = "AchievementPage.html"; 
});

  // Check if the user is logged in
  if (userId) {
      const docRef = doc(db, "users", userId);
      getDoc(docRef).then((docSnap) => {
          if (docSnap.exists) {
              const userData = docSnap.data();
              userNameElement.innerHTML = `<strong>${userData.firstName} ${userData.lastName}</strong>`;

              // Update the profile picture and other details
              const profilePic = document.querySelector('.dropdown-user-icon');
              profilePic.src = userData.profilePicUrl || "https://cdn-icons-png.flaticon.com/512/219/219983.png"; // Default image if not set

          } else {
              console.log("No user document found!");
          }
      }).catch((error) => {
          console.log("Error getting user document:", error);
      });
  } else {
      console.log("User not logged in.");
  }

  
  
  const homepageLessonsContainer = document.getElementById("homepageLessonsContainer");
      homepageLessonsContainer.innerHTML = "<p>Loading featured lessons...</p>";
    
      const lessonsCollection = collection(db, "lessons");
      getDocs(lessonsCollection).then((querySnapshot) => {
        let lessonsHtml = '';
        querySnapshot.forEach((doc) => {
          const lesson = doc.data();
          if (lesson.status !== "draft") {
            lessonsHtml += `
              <div class="lesson-button" data-lesson-id="${doc.id}">
                <h3>${lesson.title}</h3>
                <p>${lesson.description}</p>
                <p>language: ${lesson.language}</p>
                <p class="lesson-dates">Starts: ${lesson.startDate} | Ends: ${lesson.endDate}</p>
              </div>
            `;
          }
        });
    
       // Assuming you're rendering the lessons dynamically on the homepage
         homepageLessonsContainer.innerHTML = lessonsHtml || '<p class="no-data-found">No featured lessons available.</p>';

         const lessonButtons = document.querySelectorAll('.lesson-button');
        lessonButtons.forEach(button => {
        button.addEventListener('click', function() {
            const lessonId = button.getAttribute('data-lesson-id');
            window.location.href = `lessonPage.html?lessonId=${lessonId}`;            
    });  
});
});
  
 
    const searchButton = document.querySelector('.search-button');
    const searchInput = document.querySelector('.search-input');
    const authLinks = document.querySelectorAll('.auth-link');
    const searchMessage = document.getElementById('searchMessage');
    
     // Clear search input and message when clicked
     searchInput.addEventListener('click', function() {
        this.value = '';
        this.classList.remove('highlight');
        searchMessage.textContent = '';
    });
    
    // Search functionality
    searchButton.addEventListener('click', function() {
        performSearch();
    });
    
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            performSearch();
        }
    });
    
    function performSearch() {
        const searchTerm = searchInput.value.trim().toLowerCase();
        if (searchTerm) {
            searchInput.classList.add('highlight');
            let matchFound = false;
    
            const lessonButtons = document.querySelectorAll('.lesson-button');
            lessonButtons.forEach(button => {
                const title = button.querySelector('h3').textContent.toLowerCase();
                const description = button.querySelector('p').textContent.toLowerCase();
                if (title.includes(searchTerm) || description.includes(searchTerm)) {
                    button.style.display = 'block';
                    matchFound = true;
                } else {
                    button.style.display = 'none';
                }
            });
    
            searchMessage.textContent = matchFound ? '' : 'No lessons found matching your search.';
        } else {
            searchInput.classList.remove('highlight');
            searchMessage.textContent = 'Please enter a search term.';
        }
    }
    
    
    
    // Chatbot functionality
    const chatbotIcon = document.querySelector(".chatbot-icon img");
    const chatbotContainer = document.getElementById("chatbot-container");
    const closeChatbotButton = document.getElementById("close-chatbot");
    
    // Show chatbot when clicking the icon
    chatbotIcon.addEventListener("click", () => {
        chatbotContainer.classList.add("show");
    });
    
    // Hide chatbot when clicking the close button
    closeChatbotButton.addEventListener("click", () => {
        chatbotContainer.classList.remove("show");
    });


 
    document.getElementById('signOutBtn').addEventListener('click', function (event) {
        event.preventDefault();
      
        // Show custom logout modal
        document.getElementById('logoutModal').style.display = 'block';
      });
      
      document.getElementById('confirmLogoutBtn').addEventListener('click', function () {
        signOut(auth).then(() => {
          window.location.href = "MainHomepage.html";
        }).catch((error) => {
          console.error("Sign out error:", error);
        });
      });
      
      document.getElementById('cancelLogoutBtn').addEventListener('click', function () {
        // Hide modal if cancelled
        document.getElementById('logoutModal').style.display = 'none';
      });      
});