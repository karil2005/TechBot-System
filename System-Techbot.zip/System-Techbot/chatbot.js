// At the top of your file
const API_URL = 'https://openrouter.ai/api/v1/chat/completions';
const APP_NAME = "Techbot";
const ORIGIN = window.location.origin;

// Get DOM elements
let chatBody;
let messageInput;
let sendMessageButton;
let chatbotIcon;
let chatbotContainer;
let closeChatbotBtn;
const userData = { message: null };
const API_KEY = "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";
let isProcessing = false;

function sanitizeHTML(str) {
  const temp = document.createElement('div');
  temp.textContent = str;
  return temp.innerHTML;
}

const createMessageElement = (content, ...classes) => {
    const div = document.createElement("div");
    div.classList.add("message", ...classes);
    div.innerHTML = content;
    return div;
}

const generateBotResponse = async (incomingMessageDiv) => {
    const messageElement = incomingMessageDiv.querySelector(".message-text");
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 10000);

    try {
        const requestOptions = {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${API_KEY}`,
                "HTTP-Referer": ORIGIN,
                "X-Title": APP_NAME,
                "Origin": ORIGIN
            },
            body: JSON.stringify({
                messages: [
                    { role: "user", content: userData.message }
                ],
                model: 'anthropic/claude-2.1', // Using Claude 2.1 as a reliable alternative
                max_tokens: 1000,
                temperature: 0.7
            }),
            signal: controller.signal
        };

        const response = await fetch(API_URL, requestOptions);
        clearTimeout(timeoutId);

        if (!response.ok) {
            const errorText = await response.text();
            console.error("API Error Details:", errorText);
            throw new Error(`API request failed: ${response.status} - ${errorText}`);
        }

        const data = await response.json();

        if (data?.error) {
            throw new Error(data.error.message);
        }

        const apiResponseText = data.choices[0]?.message?.content?.trim() || "No valid response";
        messageElement.innerText = apiResponseText.replace(/\*\*(.*?)\*\*/g, "$1");
    } catch (error) {
        console.error("Error:", error);
        messageElement.innerText = `Sorry, I'm having trouble connecting right now. Please try again later.`;
        messageElement.style.color = "#ff0000";
    } finally {
        incomingMessageDiv.classList.remove("loading");
        chatBody.scrollTo({ top: chatBody.scrollHeight, behavior: "smooth" });
    }
}

const handleOutgoingMessage = async (e) => {
    if (isProcessing) return;
    isProcessing = true;
    
    try {
        e.preventDefault();
        const message = messageInput.value.trim();
        if (message === '') {
            isProcessing = false;
            return;
        }
        
        userData.message = sanitizeHTML(message);
        messageInput.value = "";
        
        // User message
        const outgoingMessageDiv = createMessageElement('<div class="message-text"></div>', "user-message");
        outgoingMessageDiv.querySelector(".message-text").textContent = userData.message;
        chatBody.appendChild(outgoingMessageDiv);
        chatBody.scrollTo({ top: chatBody.scrollHeight, behavior: "smooth" });

        // Bot response
        await new Promise(resolve => setTimeout(resolve, 600));
        const incomingMessageDiv = createMessageElement(
            '<svg class="bot-avatar" xmlns="http://www.w3.org/2000/svg" width="50" height="50" viewBox="0 0 1024 1024"><path d="M738.3 287.6H285.7c-59 0-106.8 47.8-106.8 106.8v303.1c0 59 47.8 106.8 106.8 106.8h81.5v111.1c0 .7.8 1.1 1.4.7l166.9-110.6 41.8-.8h117.4l43.6-.4c59 0 106.8-47.8 106.8-106.8V394.5c0-59-47.8-106.9-106.8-106.9zM351.7 448.2c0-29.5 23.9-53.5 53.5-53.5s53.5 23.9 53.5 53.5-23.9 53.5-53.5 53.5-53.5-23.9-53.5-53.5zm157.9 267.1c-67.8 0-123.8-47.5-132.3-109h264.6c-8.6 61.5-64.5 109-132.3 109zm110-213.7c-29.5 0-53.5-23.9-53.5-53.5s23.9-53.5 53.5-53.5 53.5 23.9 53.5 53.5-23.9 53.5-53.5 53.5zM867.2 644.5V453.1h26.5c19.4 0 35.1 15.7 35.1 35.1v121.1c0 19.4-15.7 35.1-35.1 35.1h-26.5zM95.2 609.4V488.2c0-19.4 15.7-35.1 35.1-35.1h26.5v191.3h-26.5c-19.4 0-35.1-15.7-35.1-35.1zM561.5 149.6c0 23.4-15.6 43.3-36.9 49.7v44.9h-30v-44.9c-21.4-6.5-36.9-26.3-36.9-49.7 0-28.6 23.3-51.9 51.9-51.9s51.9 23.3 51.9 51.9z"></path></svg><div class="message-text"><div class="loading"><div class="dot"></div><div class="dot"></div><div class="dot"></div></div></div>',
            "bot-message",
            "loading"
        );
        chatBody.appendChild(incomingMessageDiv);
        await generateBotResponse(incomingMessageDiv);
    } finally {
        isProcessing = false;
    }
}

// Function to open chatbot
function openChatbot() {
    chatbotContainer.classList.add('show');
}

// Function to close/minimize chatbot
function closeChatbot() {
    chatbotContainer.classList.remove('show');
}

document.addEventListener('DOMContentLoaded', function() {
    // Initialize DOM elements after the document has loaded
    chatBody = document.querySelector(".chat-body");
    messageInput = document.querySelector(".message-input");
    sendMessageButton = document.getElementById("send-message");
    chatbotIcon = document.getElementById('open-chatbot');
    chatbotContainer = document.getElementById('chatbot-container');
    closeChatbotBtn = document.getElementById('close-chatbot');
    
    // Event listeners
    messageInput.addEventListener("keydown", (e) => {
        if (e.key === "Enter" && messageInput.value.trim()) {
            handleOutgoingMessage(e);
        }
    });

    sendMessageButton.addEventListener("click", handleOutgoingMessage);
    
    // Event listeners for opening and closing chatbot
    chatbotIcon.addEventListener('click', openChatbot);
    closeChatbotBtn.addEventListener('click', closeChatbot);
    
    // Make sure chat form doesn't submit through normal form submission
    const chatForm = document.querySelector('.chat-form');
    if (chatForm) {
        chatForm.addEventListener('submit', (e) => {
            e.preventDefault();
            handleOutgoingMessage(e);
        });
    }
});
