import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-auth.js";
import { getFirestore, doc, getDoc } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAfyXlKY-x2Fgrz20wYYXw7AAaK1kc3SVQ",
  authDomain: "techbot-56772.firebaseapp.com",
  projectId: "techbot-56772",
  storageBucket: "techbot-56772.appspot.com",
  messagingSenderId: "1008993231244",
  appId: "1:1008993231244:web:992aae95be7e56130776a9"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", function () {
  const loggedInUserId = localStorage.getItem('loggedInUserId');
  if (loggedInUserId) {
    const docRef = doc(db, "users", loggedInUserId);
    getDoc(docRef).then((docSnap) => {
      if (docSnap.exists()) {
        const userData = docSnap.data();
        document.getElementById('loggedUserfirst-name').value = userData.firstName;
        document.getElementById('loggedUsermiddle-name').value = userData.middleName;
        document.getElementById('loggedUserlast-name').value = userData.lastName;
        document.getElementById('loggedUsersection').value = userData.section;
        document.getElementById('loggedUserStudentNumber').value = userData.studentNumber;
        document.getElementById('loggedUseremail').value = userData.email;

        const passwordField = document.querySelector('.password-display');
        passwordField.textContent = "********";

      } else {
        console.log("No user document found!");
      }
    }).catch((error) => {
      console.log("Error getting user document:", error);
    });
  } else {
    console.log("User not logged in.");
  }
});
