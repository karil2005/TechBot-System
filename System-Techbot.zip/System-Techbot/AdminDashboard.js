let tempLessonData = null;
let tempQuizData = null;

let allLessons = [];
let allDrafts = [];
let lessonToArchiveId = null;

function confirmArchive(lessonId) {
    lessonToArchiveId = lessonId;
    document.getElementById('archiveModal').style.display = 'block';
}

function closeArchiveModal() {
    document.getElementById('archiveModal').style.display = 'none';
    lessonToArchiveId = null;
}

async function proceedArchive() {
    if (!lessonToArchiveId) {
        alert("No lesson selected for archive.");
        return;
    }

    console.log("Archiving lesson ID:", lessonToArchiveId); // Add this for debugging

    const { doc, getDoc, deleteDoc, setDoc } = window.firestoreFns;

    try {
        const lessonRef = doc(window.db, "lessons", lessonToArchiveId);
        const lessonSnap = await getDoc(lessonRef);

        if (lessonSnap.exists()) {
            const lessonData = lessonSnap.data();

            // Add to archived collection
            const archivedRef = doc(window.db, "archived", lessonToArchiveId);
            await setDoc(archivedRef, lessonData);

            // Delete from lessons collection
            await deleteDoc(lessonRef);

            alert("Lesson successfully archived.");
            loadContent('learningMaterials');
        } else {
            alert("Lesson not found.");
        }
    } catch (error) {
        console.error("Error archiving lesson:", error);
        alert("Failed to archive lesson.");
    } finally {
        closeArchiveModal();
    }
}


async function loadContent(page, onLoad) {
    
    const contentDiv = document.getElementById('content');
    contentDiv.innerHTML = ''; // Clear current content

    if (page === 'dashboard') {
        const now = new Date();
        const options = { 
            month: 'long', 
            day: 'numeric', 
            year: 'numeric', 
            hour: '2-digit', 
            minute: '2-digit' 
        };
        const timestamp = now.toLocaleString('en-US', options);
        
        contentDiv.innerHTML = `
        <div class="summary">
            <h2>Summary of ${timestamp}</h2>
            <div class="stats-card">
                <canvas id="trendChart"></canvas>
            </div>
            <div class="chart-row">
                <div class="chart-container">
                    <canvas id="materialsChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="quizzesChart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="studentsChart"></canvas>
                </div>
            </div>
        </div>
    `; // Initialize charts after the content is loaded
    if (typeof onLoad === 'function') {
        onLoad();
    }
    window.initCharts?.();

    } else if (page === 'archived') {
        const { collection, getDocs } = window.firestoreFns;
    
        contentDiv.innerHTML = `
            <h2>Archived Lessons</h2>
            <div id="archivedLessonsContainer"><p>Loading archived lessons...</p></div>
        `;
    
        const archivedContainer = document.getElementById('archivedLessonsContainer');
    
        getDocs(collection(window.db, "archived")).then((querySnapshot) => {
            let archivedHtml = '';
    
            querySnapshot.forEach((doc) => {
                const lesson = doc.data();
                archivedHtml += `
                    <div class="lesson-button">
                        <h3>${lesson.title}</h3>
                        <p>${lesson.description} | Language: ${lesson.language} | Starts: ${lesson.startDate} | Ends: ${lesson.endDate}</p>
                    </div>
                `;
            });
    
            archivedContainer.innerHTML = archivedHtml || '<p class="no-data-found">No archived lessons yet.</p>';
        }).catch((error) => {
            console.error("Error fetching archived lessons:", error);
            archivedContainer.innerHTML = '<p class="no-data-found">Failed to load archived lessons.</p>';
        });
        
    } else if (page === 'learningMaterials') {
        const { collection, getDocs } = window.firestoreFns;

        contentDiv.innerHTML = `
            <div class="search-bar">
            <input 
                type="text" 
                id="searchInput" 
                placeholder="Search learning materials..." 
                onkeyup="handleSearch(event)"
                style="padding: 8px; width: 300px; max-width: 100%;"
            >
            </div>
            <div class="create-button">
                <button onclick="loadContent('createLesson')">+ Create</button>
            </div>
            <div class="drafts-section">
                <h2>Drafts</h2>
                <div id="draftsContainer">
                <p>Loading drafts...</p>
            </div>
            <div class="lessons-section">
                <h2>Lessons</h2>
               <div id="lessonsContainer">
                <p>Loading lessons...</p>
            </div>
                </div>
            </div>
            <div id="searchResult" class="no-data-found"></div>
        `;

        const lessonsContainer = document.getElementById('lessonsContainer');

    getDocs(collection(window.db, "lessons")).then((querySnapshot) => {
        let lessonsHtml = '';
        let draftsHtml = '';

        allLessons = [];
        

        querySnapshot.forEach((doc) => {
            const lesson = {id: doc.id, ...doc.data() };
            allLessons.push(lesson);
            
            if(lesson.status === "draft"){
                draftsHtml += `
               <div class="lesson-button draft" data-id="${lesson.id}">
                <h3>${lesson.title}</h3>
                <p>${lesson.description} | language: ${lesson.language} | Starts: ${lesson.startDate} | Ends: ${lesson.endDate}</p>
                 <button class="edit-draft-btn" onclick="editDraft(${JSON.stringify(lesson).replace(/"/g, '&quot;')})">Edit</button>
                </div>
                `;

            } else{
              lessonsHtml += `
                 <div class="lesson-button" data-id="${lesson.id}"> 
                    <h3>${lesson.title}</h3>
                    <p>${lesson.description} | language: ${lesson.language} | Starts: ${lesson.startDate} | Ends: ${lesson.endDate}</p>
                      <button class="archive-btn" data-archive-id="${lesson.id}">Archive</button>
                </div>
            `;
            }
        });


        lessonsContainer.innerHTML = lessonsHtml;
document.getElementById('draftsContainer').innerHTML = draftsHtml;

document.body.addEventListener('click', (e) => {
    const lessonEl = e.target.closest('.lesson-button');
    if (lessonEl && !e.target.classList.contains('archive-btn') && !e.target.classList.contains('edit-draft-btn')) {
        const lessonId = lessonEl.getAttribute('data-id');
        const lesson = allLessons.find(l => l.id === lessonId);
        if (lesson) openLessonPopup(lesson);
    }
});


// Attach archive button handlers (prevent propagation)
document.querySelectorAll('.archive-btn').forEach((btn) => {
    btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const lessonId = btn.getAttribute('data-archive-id');
        confirmArchive(lessonId);
    });
});


if (!draftsHtml) {
    document.getElementById('draftsContainer').innerHTML = '<p class="no-data-found">No drafts yet.</p>';
  }
  
  if (!lessonsHtml) {
    lessonsContainer.innerHTML = '<p class="no-data-found">No lessons yet.</p>';
  }
  
    }).catch((error) => {
        console.error("Error fetching lessons:", error);
        lessonsContainer.innerHTML = '<p class="no-data-found">Failed to load lessons.</p>';
    });

} else if (page === 'createLesson') {
    
        contentDiv.innerHTML = `
        <div class="form-group">
        <h2>Create Lesson</h2>
             <form id="lessonForm" enctype="multipart/form-data">

                <div>
                    <label for="title">Add Title </label>
                    <input type="text" id="title" placeholder="Enter title" required>
                    <div class="error-message" id="titleError"></div>
                    <label for="language" class="required-label">Choose Language</label>
                        <select id="language" class="language-select">
                            <option disabled selected>Choose Language</option>
                            <option>C++</option>
                            <option>Java</option>
                            <option>JavaScript</option>
                            <option>Python</option>
                            <option>Visual Basic</option>
                        </select>
                    <label for="badge" class="badgelabel">Choose Badge</label>
                    <select id="badge" class="badge-select">
                    <option disabled selected>Select a badge</option>
                    </select>
                    <div id="badgePreview" style="margin-top: 10px;"></div>
                </div>
                <div>
                    <label for="description">Short Description (max 150 characters) </label>
                    <textarea id="description" placeholder="Enter short description..." maxlength="150" required></textarea>
                    <div id="descriptionCounter" style="text-align: right; font-size: 12px; color: gray;">0/150</div>
                    <div class="error-message" id="descriptionError"></div>
                </div>
                <div>
                     <label>Add the Lesson (max 6000 characters)</label>
                    <div class="toolbar">
                        <button type="button" onclick="format('bold')"><b>B</b></button>
                        <button type="button" onclick="format('italic')"><i>I</i></button>
                        <button type="button" onclick="format('underline')"><u>U</u></button>
                        <input type="color" id="fontColorPicker" onchange="changeColor()">
                    </div>
                    <div id="fullLesson" contenteditable="true" class="editable" style="border: 1px solid gray; padding: 10px; min-height: 150px;" required></div>
                    <div id="fullLessonCounter" style="text-align: right; font-size: 12px; color: gray;">0/6000</div>
                    <div class="error-message" id="fullLessonError"></div>
                </div>

                <div class="date-fields">
                    <div>
                        <label for="startDate">Start Date </label>
                        <input type="date" id="startDate" required>
                        <div class="error-message" id="startDateError"></div>
                    </div>
                    <div>
                        <label for="endDate">End Date </label>
                        <input type="date" id="endDate" required>
                        <div class="error-message" id="endDateError"></div>
                    </div>
                </div>
                    <div class="button-group">
                        <button type="button" class="save-draft">Save as Draft</button>
                        <button type="button" class="cancel">Cancel</button>
                        <button type="submit" class="save">Save</button>
                        <button onclick="showQuizCreation()" class="create-quiz-btn">Create Quiz</button>
                    </div>
                    </div>
            </form>     
    `;
    
    const badgeList = [
        "Consistent Scorer.png",
        "Daily Learner.png",
        "Early Bird.png",
        "Final Shot.png",
        "First Try Finisher.png",
        "Halfway Hero.png",
        "Learning Legend.png",
        "Level Up Learner.png",
        "Night Owl.png",
        "Perfectionist.png",
        "Rise & Quiz.png",
        "Try Again Hero.png"
      ];
      
      const badgeSelect = document.getElementById('badge');
      const badgePreview = document.getElementById('badgePreview');
      
      // Fill dropdown
      badgeList.forEach(badge => {
        const option = document.createElement('option');
        option.value = badge;
        option.textContent = badge.replace(".png", "");
        badgeSelect.appendChild(option);
      });
      
      // Show preview when badge is selected
      badgeSelect.addEventListener('change', () => {
        const selected = badgeSelect.value;
        badgePreview.innerHTML = `<img src="badges/${selected}" alt="Badge Preview" style="max-height: 100px;">`;
      });
      

    document.querySelector('.create-quiz-btn').addEventListener('click', () => {
        // Save current lesson form data temporarily
    tempLessonData = {
    title: document.getElementById('title').value.trim(),
    description: document.getElementById('description').value.trim(),
    fullLesson: document.getElementById('fullLesson').innerHTML.trim(),
    startDate: document.getElementById('startDate').value,
    endDate: document.getElementById('endDate').value,
    language: document.getElementById('language').value,
    };

        showQuizCreation();
    });

    const descriptionInput = document.getElementById('description');
    const descriptionCounter = document.getElementById('descriptionCounter');

    descriptionInput.addEventListener('input', function() {
    const currentLength = descriptionInput.value.length;
    descriptionCounter.textContent = `${currentLength}/150`;
    });

    const fullLessonInput = document.getElementById('fullLesson');
    const fullLessonCounter = document.getElementById('fullLessonCounter');

    fullLessonInput.addEventListener('input', function() {
    const currentLength = fullLessonInput.innerText.length;
    fullLessonCounter.textContent = `${currentLength}/6000`;
    });

        document.querySelector('.cancel')?.addEventListener('click', () => {
    if (confirm("Discard changes and go back to Learning Materials?")) {
        loadContent('learningMaterials');
    }
});

document.querySelector('.save-draft')?.addEventListener('click', (e) => {
    e.preventDefault(); 

    const title = document.getElementById('title').value.trim();
    const description = document.getElementById('description').value.trim();
    const fullLesson = document.getElementById('fullLesson').innerHTML.trim();
    const startDate = document.getElementById('startDate').value;
    const endDate = document.getElementById('endDate').value;
    const language = document.getElementById('language').value;
    const badge = document.getElementById('badge').value;

    if (!title || !description || !fullLesson || !startDate || !endDate || !language || language === "Choose Programming Language") {
        alert("Please complete all fields before saving as draft.");
        return;
    }
    
    const draftData = {
        title,
        description,
        fullLesson,
        startDate,
        endDate,
        language,
        badge,
        status: "draft",
        quiz: tempQuizData || [], // << add this line to save the quiz with the draft!
        timestamp: new Date()
    };

    const { collection, addDoc } = window.firestoreFns;

        // If it's a new draft, add it to Firestore
        addDoc(collection(window.db, "lessons"), draftData)
            .then(() => {
                alert("Lesson (with quiz) saved as draft.");
                tempLessonData = null; // clear temp data
                tempQuizData = null;   // clear temp data
                loadContent('learningMaterials');
            })
            .catch((error) => {
                console.error("Error saving draft:", error);
                alert("Failed to save draft.");
            });
    })

    let isSubmitting = false;

    const saveBtn = contentDiv.querySelector('.save');
    if (saveBtn) {
        saveBtn.addEventListener('click', async (e) => {
            e.preventDefault();
    
            if (isSubmitting) return; // Prevent double click
            isSubmitting = true;
    
            // Optional: disable button during submission
            saveBtn.disabled = true;
    
            await validateForm(); // This handles save logic
    
            isSubmitting = false;
            saveBtn.disabled = false;
        });
    }
    
    
        const startDateInput = document.getElementById('startDate');
        const endDateInput = document.getElementById('endDate');

        // Set date range for start and end dates
        const today = new Date().toISOString().split('T')[0];
        const maxDate = '2026-12-31';

        startDateInput.setAttribute('min', today);
        startDateInput.setAttribute('max', maxDate);
        endDateInput.setAttribute('min', today);
        endDateInput.setAttribute('max', maxDate);


    } else if (page === 'studentProgress') {
        const { collection, getDocs } = window.firestoreFns;
        const contentDiv = document.getElementById('content');
    
        contentDiv.innerHTML = `
            <h2>Student Progress</h2>
            <input type="text" id="searchInput" placeholder="Search by name..." style="margin-bottom: 10px; padding: 8px; width: 100%; max-width: 400px; border-radius: 5px; border: 1px solid #ccc;" />
            <div id="studentsList"><p>Loading students...</p></div>
        `;
    
        const studentsList = document.getElementById('studentsList');
        const searchInput = document.getElementById('searchInput');
    
        getDocs(collection(window.db, "users"))
            .then((querySnapshot) => {
                const allStudents = [];
    
                querySnapshot.forEach((doc) => {
                    const user = { id: doc.id, ...doc.data() };
                    allStudents.push(user);
                });
    
                // Function to render students based on search
                function renderStudents(filterText = '') {
                    let studentHTML = '';
                    const lowerFilter = filterText.toLowerCase();
    
                    allStudents.forEach((user) => {
                        const fullName = `${user.firstName} ${user.middleName} ${user.lastName}`.toLowerCase();
                        if (fullName.includes(lowerFilter)) {
                            studentHTML += `
                                <div class="student-card" onclick="showStudentLessons('${user.id}', '${user.firstName}', '${user.lastName}')">
                                    <h3>${user.firstName} ${user.middleName} ${user.lastName}</h3>
                                    <p>Section: ${user.section} | Student No: ${user.studentNumber}</p>
                                </div>
                            `;
                        }
                    });
    
                    studentsList.innerHTML = studentHTML || '<p>No students found.</p>';
                }
    
                // Initial render
                renderStudents();
    
                // Listen for search input
                searchInput.addEventListener('input', () => {
                    renderStudents(searchInput.value);
                });
    
            })
            .catch((error) => {
                console.error("Error fetching users:", error);
                studentsList.innerHTML = '<p>Error loading students.</p>';
            });
    }
    
}

async function showStudentLessons(userId, firstName, lastName) {
    const { getDocs, collection } = window.firestoreFns;
    const contentDiv = document.getElementById('content');

    contentDiv.innerHTML = `
        <div style="display: flex; align-items: center; justify-content: space-between;">
            <button onclick="loadContent('studentProgress')" style="margin: 10px; padding: 8px 12px; background-color: #900000; color: white; border: none; border-radius: 5px; cursor: pointer;">← Back</button>
            <h2 style="flex: 1; text-align: center; margin-right: 50px;">${firstName} ${lastName}'s Achievements </h2>
        </div>
        <div id="studentAchievements" style="margin-top: 30px; display: flex; flex-direction: column; align-items: center;"><p>Loading achievements...</p></div>
    `;

    const achievementsDiv = document.getElementById('studentAchievements');

    try {
        const resultsRef = collection(window.db, "users", userId, "quizResults");
        const resultsSnap = await getDocs(resultsRef);

        let achievementHTML = ''; // Removed the heading
        let hasBadges = false;

        resultsSnap.forEach((docSnap) => {
            const data = docSnap.data();
            if (data.badge) {
                hasBadges = true;
                const badgeName = data.badge;
                const badgeImagePath = `./badges/${encodeURIComponent(badgeName)}.png`;

                achievementHTML += `
                <img src="${badgeImagePath}" alt="${badgeName}" style="height: 50px; margin-right: 10px; vertical-align: middle;">
                <span style="margin-top: 3px; font-weight: bold; font-size: 18px; color: #000070; vertical-align: middle;">${badgeName.replace('.png', '')}</span>
                <br><br>
                `;


            }
        });

        if (!hasBadges) {
            achievementHTML += "<p style='text-align: left;'>No achievements found.</p>";
        }

        achievementsDiv.innerHTML = achievementHTML;

    } catch (error) {
        console.error("Error loading student achievements:", error);
        achievementsDiv.innerHTML = "<p>Failed to load achievements.</p>";
    }
}

function editDraft(lesson) {
    tempLessonData = {
        ...lesson,
        id: lesson.id // Make sure this is set
    };
    

    loadCreateLessonPage();

    // Set the form values based on the lesson data
    setTimeout(() => {
        document.getElementById('title').value = lesson.title;
        document.getElementById('description').value = lesson.description;
        document.getElementById('fullLesson').innerHTML = lesson.fullLesson;
        document.getElementById('startDate').value = lesson.startDate;
        document.getElementById('endDate').value = lesson.endDate;
        document.getElementById('language').value = lesson.language;
        document.getElementById('badge').value = lesson.badge;
        document.getElementById('badgePreview').innerHTML = `<img src="badges/${lesson.badge}" style="max-height: 100px;">`;


        // Optionally, if the quiz is attached, load the quiz data as well
        tempQuizData = lesson.quiz;
    }, 100); // delay to ensure the form has loaded
}


function loadCreateLessonPage() {
    loadContent('createLesson');

    setTimeout(() => {
        if (tempLessonData) {
            document.getElementById('title').value = tempLessonData.title;
            document.getElementById('description').value = tempLessonData.description;
            document.getElementById('fullLesson').innerHTML = tempLessonData.fullLesson;
            document.getElementById('startDate').value = tempLessonData.startDate;
            document.getElementById('endDate').value = tempLessonData.endDate;
            document.getElementById('language').value = tempLessonData.language;
        }
    }, 100); // slight delay to make sure the form exists
}



// Function to handle learning materials search
let debounceTimer;
function handleSearch(event) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
        if (event.key === 'Enter') {
            event.preventDefault();
            const searchQuery = document.getElementById('searchInput').value.trim().toLowerCase();
            const searchResultDiv = document.getElementById('searchResult');
            const draftsContainer = document.getElementById('draftsContainer');
            const lessonsContainer = document.getElementById('lessonsContainer');

            draftsContainer.innerHTML = '';
            lessonsContainer.innerHTML = '';
            searchResultDiv.innerHTML = '';

            let found = false;

            const filteredDrafts = allLessons.filter(lesson =>
                lesson.status === 'draft' &&
                (lesson.title.toLowerCase().includes(searchQuery) ||
                lesson.description.toLowerCase().includes(searchQuery))
            );

            const filteredLessons = allLessons.filter(lesson =>
                lesson.status !== 'draft' &&
                (lesson.title.toLowerCase().includes(searchQuery) ||
                lesson.description.toLowerCase().includes(searchQuery))
            );

            if (filteredDrafts.length > 0) {
                found = true;
                draftsContainer.innerHTML = filteredDrafts.map(draft => `
                    <div class="lesson-button draft" onclick="openLessonPopup(${JSON.stringify(draft).replace(/"/g, '&quot;')})">
                        <h3>${draft.title}</h3>
                        <p>${draft.description} | Starts: ${draft.startDate} | Ends: ${draft.endDate}</p>
                    </div>
                `).join('');
            } else {
                draftsContainer.innerHTML = '<p class="no-data-found">No drafts found.</p>';
            }

            if (filteredLessons.length > 0) {
                found = true;
                lessonsContainer.innerHTML = filteredLessons.map(lesson => `
                    <div class="lesson-button" onclick="openLessonPopup(${JSON.stringify(lesson).replace(/"/g, '&quot;')})">
                        <h3>${lesson.title}</h3>
                        <p>${lesson.description} | Starts: ${lesson.startDate} | Ends: ${lesson.endDate}</p>
                    </div>
                `).join('');
            } else {
                lessonsContainer.innerHTML = '<p class="no-data-found">No lessons found.</p>';
            }

            if (!found) {
                searchResultDiv.innerHTML = `<p>No results found for "${searchQuery}".</p>`;
            }
        }
    }, 300);
}

// CREATE QUIZ FUNCTIONALITY
let currentQuestionIndex = 0;
let quizQuestions = Array(10).fill({
    questionDesc: '',
    options: ['', '', '', ''],
    correctAnswer: 0
});


function showQuizCreation() {
    // Reset quizQuestions to clear previous quiz data
    quizQuestions = Array(10).fill({
        questionDesc: '',
        options: ['', '', '', ''],
        correctAnswer: 0
    });

      // Reset current question index
      currentQuestionIndex = 0;

    renderQuestion();
}
function renderQuestion() {
    const contentDiv = document.getElementById('content');
    const question = quizQuestions[currentQuestionIndex];

    contentDiv.innerHTML = `
                <div class="quiz-header">
    <h4>Create Quiz</h4>
</div>

<form id="quizForm">
    <div class="question-section">
        <h3>Question ${currentQuestionIndex + 1} of 10</h3>

        <div class="form-group">
            <textarea id="questionDesc" placeholder="Type your question here..." maxlength="3000" required></textarea>
            <div class="error-message" id="descError"></div>
        </div>

        <div class="option-group">
            ${question.options.map((option, i) => `
                <div class="option-box ${question.correctAnswer === i ? 'selected' : ''}" data-index="${i}">
                    <div class="indicator">
                          <span class="x-icon" style="${question.correctAnswer === i ? 'display:none;' : 'display:inline;'}">✖</span>
                                <span class="o-icon" style="${question.correctAnswer === i ? 'display:inline;' : 'display:none;'}">✔</span>
                            </div>
                            <textarea class="option-input" placeholder="Option ${i + 1}" required>${option}</textarea>
                        </div>
                    `).join('')}
                </div>

        <div class="error-message" id="optionsError"></div>
    </div>

    <div class="form-actions">
        <button type="button" class="back-btn">Back</button>
        <button type="submit" class="next-btn">${currentQuestionIndex === 9 ? 'Finish' : 'Next'}</button>
    </div>
</form>

    `;
    setupQuizEvents();
}

function setupQuizEvents() {
    document.querySelectorAll('.option-box').forEach(box => {
        box.addEventListener('click', (e) => {
            if (e.target.classList.contains('option-input')) return;
    
            document.querySelectorAll('.option-box').forEach(b => {
                b.classList.remove('selected');
                b.querySelector('.o-icon').style.display = 'none';
                b.querySelector('.x-icon').style.display = 'inline';
            });
            
            box.classList.add('selected');
            box.querySelector('.o-icon').style.display = 'inline';
            box.querySelector('.x-icon').style.display = 'none';
        });
    });
    
    document.getElementById('quizForm').addEventListener('submit', (e) => {
        e.preventDefault();
        saveCurrentQuestion();
        
        if (currentQuestionIndex < 9) {
            currentQuestionIndex++;
            renderQuestion();
        } else {
            saveQuiz();
        }
    });

     document.querySelector('.back-btn').addEventListener('click', () => {
        if (currentQuestionIndex > 0) {
            currentQuestionIndex--;
            renderQuestion();
        } else {
            if (confirm('Are you sure you want to go back? Progress will be lost.')) {
                loadContent('learningMaterials');
            }
        }
    });
}

function saveCurrentQuestion() {
    const questionDesc = document.getElementById('questionDesc').value.trim();
    const optionInputs = document.querySelectorAll('.option-input');
    const options = Array.from(optionInputs).map(input => input.value.trim());

    let correctAnswer = 0;
    document.querySelectorAll('.option-box').forEach((box, index) => {
        if (box.classList.contains('selected')) {
            correctAnswer = index;
        }
    });

    quizQuestions[currentQuestionIndex] = {
        questionDesc,
        options,
        correctAnswer
    };
}

function saveQuiz() {
    console.log("Final Quiz Data:", quizQuestions);
    tempQuizData = quizQuestions;  // Save quiz data temporarily
    alert('Quiz saved successfully! Now back to Lesson creation.');

    // Save quiz data to localStorage
    localStorage.setItem('quizData', JSON.stringify(quizQuestions));

    loadCreateLessonPage(); // instead of loadContent('learningMaterials')
}

// Function to validate the form
async function validateForm() {

    const titleInput = document.getElementById('title');
    const descriptionInput = document.getElementById('description');
    const fullLessonInput = document.getElementById('fullLesson');
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    const languageInput = document.getElementById('language');
    const badgeInput = document.getElementById('badge');
    const quizInput = tempQuizData;

    let isValid = true;

    if (!titleInput.value.trim()) {
        document.getElementById('titleError').textContent = 'This field is required.';
        titleInput.classList.add('error-field');
        isValid = false;
    } else {
        document.getElementById('titleError').textContent = '';
        titleInput.classList.remove('error-field');
    }

    if (!descriptionInput.value.trim()) {
        document.getElementById('descriptionError').textContent = 'This field is required.';
        descriptionInput.classList.add('error-field');
        isValid = false;
    } else {
        document.getElementById('descriptionError').textContent = '';
        descriptionInput.classList.remove('error-field');
    }

    if (!fullLessonInput.innerHTML.trim()) {
        document.getElementById('fullLessonError').textContent = 'This field is required.';
        fullLessonInput.classList.add('error-field');
        isValid = false;
    } else {
        document.getElementById('fullLessonError').textContent = '';
        fullLessonInput.classList.remove('error-field');
    }

    if (!startDateInput.value) {
        document.getElementById('startDateError').textContent = 'This field is required.';
        startDateInput.classList.add('error-field');
        isValid = false;
    } else {
        document.getElementById('startDateError').textContent = '';
        startDateInput.classList.remove('error-field');
    }

    if (!endDateInput.value) {
        document.getElementById('endDateError').textContent = 'This field is required.';
        endDateInput.classList.add('error-field');
        isValid = false;
    } else {
        document.getElementById('endDateError').textContent = '';
        endDateInput.classList.remove('error-field');
    }

    if (!languageInput.value || languageInput.value === "Choose Programming Language") {
        alert("Please select a programming language.");
        isValid = false;
    }

    if (!badgeInput.value || badgeInput.value === "Select a badge") {
        alert("Please select a badge.");
        isValid = false;
    }

    if (!quizInput || quizInput.length === 0) {
        alert("Please create a quiz for the lesson.");
        isValid = false;
    }

    if (isValid) {

        const lessonData = {
            title: titleInput.value,
            description: descriptionInput.value,
            fullLesson: fullLessonInput.innerHTML,
            startDate: startDateInput.value,
            endDate: endDateInput.value,
            language: languageInput.value,
            badge: badgeInput.value,
            quiz: tempQuizData || [], // Save the quiz here!
            timestamp: new Date(),
            status: "Published"
                     
        
        };
    
        const { collection, addDoc, doc, updateDoc } = window.firestoreFns;
         // If we're editing an existing draft, update the document
         
         try {
            if (tempLessonData?.id) {
                const lessonRef = doc(window.db, "lessons", tempLessonData.id);
                await updateDoc(lessonRef, lessonData);
                alert("Lesson updated successfully.");
                tempLessonData = null;
                tempQuizData = null;
                loadContent('learningMaterials');
            } else {
                await addDoc(collection(window.db, "lessons"), lessonData);
                alert("Lesson and Quiz saved successfully to database!");
                tempLessonData = null;
                tempQuizData = null;
                loadContent('learningMaterials');
            }
        } catch (error) {
            console.error("Error during database operation:", error);
            alert("Failed to save lesson.");
        }
    }

    isSubmitting = false;  // Reset flag after validation and saving
}


function openLessonPopup(lesson) {
    const existingPopup = document.getElementById('lessonPopup');
    if (existingPopup) existingPopup.remove();

    const popup = document.createElement('div');
    popup.id = 'lessonPopup';
    popup.classList.add('popup-overlay');
    popup.innerHTML = `
        <div class="lesson-popup-container">
            <div class="lesson-popup-header">
                <h2>${lesson.title}</h2>
                <button class="popup-close" onclick="closeLessonPopup()">×</button>
            </div>
            <div class="lesson-popup-body">
                <div id="lessonContent">
                    ${lesson.fullLesson ? lesson.fullLesson.replace(/\n/g, '<br>') : '<i>No lesson content available.</i>'}
                </div>
                <div id="quizContent" style="display: none;">
                    <h4>Quiz</h4>
                    ${lesson.quiz && lesson.quiz.length > 0 ? lesson.quiz.map((question, index) => `
                        <div class="quiz-question">
                            <h5>Question ${index + 1}</h5>
                            <p>${question.questionDesc}</p>
                            <ul>
                                ${question.options.map((option, i) => `<li>${i + 1}. ${option}</li>`).join('')}
                            </ul>
                            <p><strong>Correct Answer: ${question.options[question.correctAnswer]}</strong></p> <!-- Show the correct option as the answer -->
                        </div>
                    `).join('') : '<p>No quiz available for this lesson.</p>'}
               <!-- Badge inside quiz view -->
            ${lesson.badge ? `
            <div style="margin-top: 20px; text-align: center;">
            <h4>Badge:</h4>
            <img src="badges/${lesson.badge}" alt="Badge Image" style="max-height: 120px;">
            <p>${lesson.badge.replace(".png", "")}</p>
        </div>
        ` : ''}
            </div>

                <div class="lesson-popup-footer">
                <button class="view-quiz-btn" onclick="toggleQuizView('quiz')">View Quiz</button>
                <button class="back-to-lesson-btn" style="display: none;" onclick="toggleQuizView('lesson')">Back to Lesson</button>
            </div>
            </div>
    `;
    document.body.appendChild(popup);
}


function closeLessonPopup() {
    const popup = document.getElementById('lessonPopup');
    if (popup) popup.remove();
}

function toggleQuizView(viewType) {
    console.log("Toggling view:", viewType); // Add this
    const lessonContent = document.getElementById('lessonContent');
    const quizContent = document.getElementById('quizContent');
    const viewQuizButton = document.querySelector('.view-quiz-btn');
    const backToLessonButton = document.querySelector('.back-to-lesson-btn');

    if (viewType === 'quiz') {
        // Hide lesson content, show quiz content
        lessonContent.style.display = "none";
        quizContent.style.display = "block";
        viewQuizButton.style.display = "none"; // Hide "View Quiz" button
        backToLessonButton.style.display = "inline-block"; // Show "Back to Lesson" button
    } else if (viewType === 'lesson') {
        // Show lesson content, hide quiz content
        lessonContent.style.display = "block";
        quizContent.style.display = "none";
        viewQuizButton.style.display = "inline-block"; // Show "View Quiz" button
        backToLessonButton.style.display = "none"; // Hide "Back to Lesson" button
    }
}




function format(command) {
    document.execCommand(command, false, null);
}

function changeColor() {
    const color = document.getElementById('fontColorPicker').value;
    document.execCommand('foreColor', false, color);
}

function initCreateLessonEvents() {
    const descriptionInput = document.getElementById('description');
    const descriptionCounter = document.getElementById('descriptionCounter');

    descriptionInput.addEventListener('input', function() {
        descriptionCounter.textContent = `${this.value.length}/150`;
    });

    const today = new Date().toISOString().split('T')[0];
    const maxDate = '2026-12-31';
    const startDateInput = document.getElementById('startDate');
    const endDateInput = document.getElementById('endDate');
    startDateInput.setAttribute('min', today);
    endDateInput.setAttribute('min', today);
    startDateInput.setAttribute('max', maxDate);
    endDateInput.setAttribute('max', maxDate);

    document.querySelector('.cancel')?.addEventListener('click', () => {
        if (confirm("Discard changes and go back to Learning Materials?")) {
            loadContent('learningMaterials');
        }
    });
    
}
  



// Load default content
loadContent('dashboard');