import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-app.js";
import { getFirestore, collection, getDocs } from "https://www.gstatic.com/firebasejs/11.6.0/firebase-firestore.js";

const firebaseConfig = {
  apiKey: "AIzaSyAfyXlKY-x2Fgrz20wYYXw7AAaK1kc3SVQ",
  authDomain: "techbot-56772.firebaseapp.com",
  projectId: "techbot-56772",
  storageBucket: "techbot-56772.appspot.com",
  messagingSenderId: "1008993231244",
  appId: "1:1008993231244:web:992aae95be7e56130776a9"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", async () => {
    const userId = localStorage.getItem("loggedInUserId");
    if (!userId) {
        console.error("No logged in user ID found");
        return;
    }

    const resultsRef = collection(db, "users", userId, "quizResults");
    const querySnapshot = await getDocs(resultsRef);

    const achievementsContainer = document.getElementById("achievementsList");

    querySnapshot.forEach((docSnap) => {
        const data = docSnap.data();
        if (data.badge) {
            const badgeName = data.badge;  // Use exact name from Firestore
            const badgeImagePath = `./badges/${encodeURIComponent(badgeName)}.png`;


            const achievementCard = document.createElement("div");
            achievementCard.style.marginTop = "20px";
            achievementCard.style.textAlign = "center";
            achievementCard.style.display = "flex";
            achievementCard.style.flexDirection = "column"; // Arrange vertically
            achievementCard.style.alignItems = "flex-start"; // Align to left
            achievementCard.style.color = "#000070";

            achievementCard.innerHTML = `
            <p style="margin-bottom: 7px; font-weight: bold; font-size: 20px">${badgeName.replace('.png', '')}</p>
            <img src="${badgeImagePath}" alt="${badgeName}" style="max-height: 120px;">
            `;

            achievementsContainer.appendChild(achievementCard);
        }
    });
});

window.closeOverlay = function () {
    window.location.href = "homepageicon.html";
};
